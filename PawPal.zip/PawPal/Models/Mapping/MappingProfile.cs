﻿using AutoMapper;
using PawPal.Data.Identity;

namespace PawPal.Models.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            this.CreateMap<Animal, AnimalModel>()
                .ForMember(dst => dst.Birthday,
                opt => opt.MapFrom(src => src.Birthday.Date))
                .ForMember(dst => dst.NewName,
                opt => opt.MapFrom(src => src.Name));
            this.CreateMap<AnimalModel, Animal>();
        }
    }
}
