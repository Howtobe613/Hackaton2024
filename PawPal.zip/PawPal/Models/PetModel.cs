﻿namespace PawPal.Models
{
    public class PetModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Breed { get; set; }
        public bool Gender { get; set; }
        public DateTime Birthday { get; set; }
        public double Weight { get; set; }
        public double Temperature { get; set; }
        public int BPM { get; set; }
        public DateTime DoctorMeet { get; set; }
        public string Owner { get; set; }
        public string Adress { get; set; }
        public string Illness { get; set; }
        public string FullName { get; set; }

    }
}
