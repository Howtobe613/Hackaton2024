﻿using Microsoft.AspNetCore.Identity.UI.Services;

namespace PawPal.Services.Email
{
    public class EmailSender : IEmailSender
    {
        public async Task SendEmailAsync(string email, string subject, string htmlMessage)
        {
            //TODO Create email services
            await Task.CompletedTask;
        }
    }
}
