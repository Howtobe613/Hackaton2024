﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PawPal.Data.Migrations
{
    public partial class newtablePets : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                schema: "data",
                table: "Pets",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Birthday", "DoctorMeet", "Illness" },
                values: new object[] { new DateTime(2021, 4, 27, 16, 42, 24, 704, DateTimeKind.Local).AddTicks(3200), new DateTime(2024, 5, 27, 16, 42, 24, 704, DateTimeKind.Local).AddTicks(3220), "none" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                schema: "data",
                table: "Pets",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Birthday", "DoctorMeet", "Illness" },
                values: new object[] { new DateTime(2021, 4, 27, 15, 53, 11, 39, DateTimeKind.Local).AddTicks(6157), new DateTime(2024, 5, 27, 15, 53, 11, 39, DateTimeKind.Local).AddTicks(6188), "" });
        }
    }
}
