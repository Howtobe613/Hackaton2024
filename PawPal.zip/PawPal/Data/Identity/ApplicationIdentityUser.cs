﻿using Microsoft.AspNetCore.Identity;

namespace PawPal.Data.Identity
{
    public class ApplicationIdentityUser : IdentityUser
    {
        public long ApplicarionId { get; set; }
    }
}
