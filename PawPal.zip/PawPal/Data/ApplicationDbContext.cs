﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using PawPal.Data.Identity;

namespace PawPal.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationIdentityUser, IdentityRole, string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Pet>().Property(z => z.Id).UseIdentityColumn();
            builder.Entity<Pet>().Property(z => z.Name).HasMaxLength(30);
            builder.Entity<Pet>().Property(z => z.Breed).HasMaxLength(20);
            builder.Entity<Pet>().HasData(
                new Pet
                {
                    Id = 1,
                    Name = "Pushok",
                    Breed = "Chihuahua",
                    Gender = false,
                    Birthday = DateTime.Now.AddYears(-3),
                    Weight = 5.7,
                    Temperature = 37.7,
                    BPM = 120,
                    DoctorMeet = DateTime.Now.AddDays(30),
                    Owner = "Efimova Ulyana Dmitrievna",
                    Adress = "Makarenko 36",
                    Illness = "none",
                });

            base.OnModelCreating(builder);
        }

        public DbSet<Pet> Pets { get; set; }
    }
}
