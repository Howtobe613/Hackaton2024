using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PawPal.Pages
{
    public class FirstPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
