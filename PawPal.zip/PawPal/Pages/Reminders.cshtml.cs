using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PawPal.Pages
{
    public class RemindersModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
