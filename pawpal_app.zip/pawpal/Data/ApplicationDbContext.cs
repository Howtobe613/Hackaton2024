﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using PawPal.Data.Identity;

namespace PawPal.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationIdentityUser, IdentityRole, string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Animal>().Property(z => z.Id).UseIdentityColumn();
            builder.Entity<Animal>().Property(z => z.Name).HasMaxLength(25);
            builder.Entity<Animal>().Property(z => z.Breed).HasMaxLength(25);
            builder.Entity<Animal>().HasData(
                new Animal
                {
                    Id = 1,
                    Name = "Timosha",
                    Breed = "British",
                    Gender = true,
                    Birthday = DateTime.Now.AddYears(-3),
                    Weight = 5.4,
                    Temperature = 37.7,
                    BPM = 130,
                    DoctorMeet = DateTime.Now.AddDays(20),
                    Owner = "Airapetova Anna Nikolaevna",
                    Adress = "Tula, Lermontova-7 street",
                    Illness = "None",
                });
            base.OnModelCreating(builder);
        }
        public DbSet<Animal> Animals { get; set; }
    }
}
