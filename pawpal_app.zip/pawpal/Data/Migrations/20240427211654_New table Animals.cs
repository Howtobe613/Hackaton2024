﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PawPal.Data.Migrations
{
    public partial class NewtableAnimals : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "data");

            migrationBuilder.CreateTable(
                name: "Animals",
                schema: "data",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: false),
                    Breed = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: false),
                    Gender = table.Column<bool>(type: "bit", nullable: false),
                    Birthday = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Weight = table.Column<double>(type: "float", nullable: false),
                    Temperature = table.Column<double>(type: "float", nullable: false),
                    BPM = table.Column<int>(type: "int", nullable: false),
                    DoctorMeet = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Owner = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Adress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Illness = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Animals", x => x.Id);
                });

            migrationBuilder.InsertData(
                schema: "data",
                table: "Animals",
                columns: new[] { "Id", "Adress", "BPM", "Birthday", "Breed", "DoctorMeet", "Gender", "Illness", "Name", "Owner", "Temperature", "Weight" },
                values: new object[] { 1, "Tula, Lermontova-7 street", 130, new DateTime(2021, 4, 28, 0, 16, 54, 91, DateTimeKind.Local).AddTicks(7806), "British", new DateTime(2024, 5, 18, 0, 16, 54, 91, DateTimeKind.Local).AddTicks(7841), true, "None", "Timosha", "Airapetova Anna Nikolaevna", 37.700000000000003, 5.4000000000000004 });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Animals",
                schema: "data");
        }
    }
}
