import 'package:flutter/material.dart';
import 'package:pawpal/PetsPage.dart';
import 'package:pawpal/main.dart';


class Pets_Page extends StatefulWidget {
  const Pets_Page({Key? key}) : super(key: key);

  @override
  State<Pets_Page> createState() => _Pets_Page();
}

class _Pets_Page extends State<Pets_Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('Добро пожаловать User', style: TextStyle(color: Colors.white),),
      ),
      body: Center(
        child: Column(
          children: [
            Container(
             decoration: BoxDecoration( borderRadius: BorderRadius.circular(10),
             color: Colors.black12),
              width: 1000,
              height: 680,
              child: Column(children: [
                Row(
                  children: [
                    Padding(padding: EdgeInsets.fromLTRB(40, 40, 20, 20),child:
                    Text('Добро пожаловать в\nPawPal',style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color:Colors.deepOrangeAccent), )
                 ),
                
                 ],
                ),
                 Padding(padding: EdgeInsets.fromLTRB(10,10,10,20),
                              child:
                          SizedBox(
                               width: 450,
                                 child: TextField(
                                   
        
                                decoration: InputDecoration(
                                  
                                border: OutlineInputBorder(),
                                labelText: 'Ваш питомец',
        ),
      ),
                          )
                      ), 
                       Padding(padding: EdgeInsets.fromLTRB(10,10,10,20),
                              child:
                          SizedBox(
                               width: 450,
                                 child: TextField(
                                   
        
                                decoration: InputDecoration(
                                  
                                border: OutlineInputBorder(),
                                labelText: 'Кличка',
        ),
      ),
                          )
                      ), 
                      Padding(padding: EdgeInsets.fromLTRB(10,10,10,20),
                              child:
                          SizedBox(
                               width: 450,
                                 child: TextField(
                                   
        
                                decoration: InputDecoration(
                                  
                                border: OutlineInputBorder(),
                                labelText: 'Порода',
        ),
      ),
                          )
                      ), 
                      Padding(padding: EdgeInsets.fromLTRB(10,10,10,20),
                              child:
                          SizedBox(
                               width: 450,
                                 child: TextField(
                                   
        
                                decoration: InputDecoration(
                                  
                                border: OutlineInputBorder(),
                                labelText: 'Возраст',
        ),
      ),
                          )
                      ), 
                      Row(
                          children: [
                            Padding(padding: EdgeInsets.fromLTRB(10, 10, 50, 10), child:
                             Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration( borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black, width: 5),
                    
                      color:Colors.white),
                    width: 100,
                    height: 60,
                  
                    child: 
                    
                  MaterialButton(
                    
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Pets_Page()));
                    },
                    child: Text("М", style: TextStyle(fontSize: 20),),
                  )
                  )), Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration( borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black, width: 5),
                    
                      color:Colors.white),
                    width: 100,
                    height: 60,
                  
                    child: 
                    
                  MaterialButton(
                    
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Pets_Page()));
                    },
                    child: Text("М", style: TextStyle(fontSize: 20),),
                  )
                  )
                          ],
                      ),
                      
                      Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration( borderRadius: BorderRadius.circular(10),
                    
                      color:Colors.deepOrangeAccent),
                    width: 250,
                    height: 60,
                  
                    child: 
                    
                  MaterialButton(
                    
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => PetsPage()));
                    },
                    child: Text("Добавить", style: TextStyle(fontSize: 20),),
                  )
                  )
              ],),
            )
          ],

        ),
      ),
    );
  }
}
