import 'package:flutter/material.dart';
import 'package:pawpal/Registr.dart';


class Auth_Page extends StatefulWidget {
  const Auth_Page({Key? key}) : super(key: key);

  @override
  State<Auth_Page> createState() => _Auth_Page();
}

class _Auth_Page extends State<Auth_Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('PawPal', style: TextStyle(color: Colors.white),),
      ),
      body: Center(
        child: Column(
          children: [
            Container(
             decoration: BoxDecoration( borderRadius: BorderRadius.circular(10),
             color: Colors.black12),
              width: 1000,
              height: 680,
              child: Column(children: [
                Row(
                  children: [
                    Padding(padding: EdgeInsets.fromLTRB(40, 40, 20, 20),child:
                    Text('Добро пожаловать в\nPawPal',style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color:Colors.deepOrangeAccent), )
                 ),
                
                 ],
                ),
                 Padding(padding: EdgeInsets.fromLTRB(10,10,10,20),
                              child:
                          SizedBox(
                               width: 450,
                                 child: TextField(
                                   
        
                                decoration: InputDecoration(
                                  
                                border: OutlineInputBorder(),
                                labelText: 'Адрес электронной почты',
        ),
      ),
                          )
                      ), 
                       Padding(padding: EdgeInsets.fromLTRB(10,10,10,20),
                              child:
                          SizedBox(
                               width: 450,
                                 child: TextField(
                                   obscureText: true,
        
                                decoration: InputDecoration(
                                  
                                border: OutlineInputBorder(),
                                labelText: 'Пароль',
        ),
      ),
                          )
                      ), 
                       Padding(padding: EdgeInsets.fromLTRB(10,10,10,50),
                              child:
                          SizedBox(
                               width: 450,
                                 child: TextField(
                                   obscureText: true,
        
                                decoration: InputDecoration(
                                  
                                border: OutlineInputBorder(),
                                labelText: 'Повторите пароль',
        ),
      ),
                          )
                      ), 
                      Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration( borderRadius: BorderRadius.circular(10),
                    
                      color:Colors.deepOrangeAccent),
                    width: 250,
                    height: 60,
                  
                    child: 
                    
                  MaterialButton(
                    
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Reg_page()));
                    },
                    child: Text("Зарегистрироваться", style: TextStyle(fontSize: 20),),
                  )
                  )
              ],),
            )
          ],

        ),
      ),
    );
  }
}
