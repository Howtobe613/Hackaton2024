import 'package:flutter/material.dart';

class PetsPage extends StatefulWidget {
  const PetsPage({Key? key}) : super(key: key);

  @override
  State<PetsPage> createState() => _PetsPage();
}

class _PetsPage extends State<PetsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
            children: [
              Row(
                children: [
                  Padding(padding: EdgeInsets.fromLTRB(30, 20, 30, 20),child:
                  CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 50,
                    child:Image.asset('cat.png')
                   ) ),Padding(padding: EdgeInsets.fromLTRB(0, 20, 30, 20),
                   child:Text('UserName', style: TextStyle(fontSize: 30, color: Colors.white, fontWeight: FontWeight.w900),)
                   )
                ],
              ),Row(
                children: [
                  Padding(padding: EdgeInsets.fromLTRB(30, 20, 30, 20),child:
                  Container(
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.greenAccent,),
                    
                    width: 200,
                    height: 100,
                    child: Text('Вес\n7 кг', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color:Colors.white),textAlign: TextAlign.center,),
                    )  ),
                    Padding(padding: EdgeInsets.fromLTRB(0, 20, 30, 20),child:
                  Container(
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.greenAccent,),
                    
                    width: 200,
                    height: 100,
                    child: Text('Порода\nБританец', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color:Colors.white),textAlign: TextAlign.center,),
                    )  )
                ],
              ),
              Row(
                children: [
                  Padding(padding: EdgeInsets.fromLTRB(30, 20, 30, 20),child:
                  Container(
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.greenAccent,),
                    
                    width: 200,
                    height: 100,
                    child: Text('Возраст\n5 лет', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color:Colors.white),textAlign: TextAlign.center,),
                    )  ),
                    Padding(padding: EdgeInsets.fromLTRB(0, 20, 30, 20),child:
                  Container(
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.greenAccent,),
                    
                    width: 200,
                    height: 100,
                    child: Text('Пол\nМужской', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color:Colors.white),textAlign: TextAlign.center,),
                    )  )
                ],
              ),
               Row(
                children: [
                  Padding(padding: EdgeInsets.fromLTRB(30, 20, 30, 20),child:
                  Container(
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.deepOrangeAccent,),
                    
                    width: 450,
                    height: 100,
                    child: Row(
                      children: [
                    Text('перейти\nК мед карте', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color:Colors.white),textAlign: TextAlign.center,),
                    Padding(padding: EdgeInsets.fromLTRB(180, 20, 30, 20),
                 child: Image.asset('zd.png'),
                 )
                
                 ] ) ) ,
                 
                  ),
                 
                ],
              ),
               Row(
                children: [
                  Padding(padding: EdgeInsets.fromLTRB(30, 20, 30, 20),child:
                  Container(
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.deepOrangeAccent,),
                    
                    width: 450,
                    height: 100,
                    child: Row(
                      children: [
                    Text('Здоровье', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color:Colors.white),textAlign: TextAlign.center,),
                    Padding(padding: EdgeInsets.fromLTRB(200, 20, 30, 20),
                 child: Image.asset('med.png'),
                 )
                
                 ] ) ) ,
                 
                  ),
                 
                ],
              ),
            ],
        ),
      ),
    );
  }
}
