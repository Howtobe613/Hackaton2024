import 'package:flutter/material.dart';
import 'package:pawpal/Pets.dart';
import 'package:pawpal/main.dart';


class Reg_page extends StatefulWidget {
  const Reg_page({Key? key}) : super(key: key);

  @override
  State<Reg_page> createState() => _Reg_page();
}

class _Reg_page extends State<Reg_page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('PawPal', style: TextStyle(color: Colors.white),),
      ),
      body: Center(
        child: Column(
          children: [
            Container(
             decoration: BoxDecoration( borderRadius: BorderRadius.circular(10),
             color: Colors.black12),
              width: 1000,
              height: 680,
              child: Column(children: [
                Row(
                  children: [
                    Padding(padding: EdgeInsets.fromLTRB(40, 40, 20, 20),child:
                    Text('Добро пожаловать в\nPawPal',style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color:Colors.deepOrangeAccent), )
                 ),
                
                 ],
                ),
                 Padding(padding: EdgeInsets.fromLTRB(10,10,10,20),
                              child:
                          SizedBox(
                               width: 450,
                                 child: TextField(
                                   
        
                                decoration: InputDecoration(
                                  
                                border: OutlineInputBorder(),
                                labelText: 'Адрес электронной почты',
        ),
      ),
                          )
                      ), 
                       Padding(padding: EdgeInsets.fromLTRB(10,10,10,20),
                              child:
                          SizedBox(
                               width: 450,
                                 child: TextField(
                                   obscureText: true,
        
                                decoration: InputDecoration(
                                  
                                border: OutlineInputBorder(),
                                labelText: 'Пароль',
        ),
      ),
                          )
                      ), 
                      
                      Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration( borderRadius: BorderRadius.circular(10),
                    
                      color:Colors.deepOrangeAccent),
                    width: 250,
                    height: 60,
                  
                    child: 
                    
                  MaterialButton(
                    
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Pets_Page()));
                    },
                    child: Text("Войти", style: TextStyle(fontSize: 20),),
                  )
                  )
              ],),
            )
          ],

        ),
      ),
    );
  }
}
