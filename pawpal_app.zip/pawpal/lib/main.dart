import 'package:flutter/material.dart';
import 'package:pawpal/Auth.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
            children: [
              Padding(padding: EdgeInsets.fromLTRB(100, 50, 100, 10), child: 
              Text('Pawpal', style: TextStyle(fontSize: 60, color:Colors.greenAccent),)
         ),
         Row(
          children: [
         Padding(padding: EdgeInsets.fromLTRB(50, 20, 20, 20),
         child: Text('Ваша забота\nо питомце\nначинается здесь', style: TextStyle(fontSize: 25, color: Colors.white, fontWeight: FontWeight.w900),),
         )
         ] ), Row(
          children: [
         Padding(padding: EdgeInsets.fromLTRB(20, 20, 100, 50),
         child: Text('Поможем вам следить за здоровьем вашего\nлюбимца. Присоединяйтесь!', style: TextStyle(fontSize: 15, color: Colors.white, fontWeight: FontWeight.w900),),
         )
         ] ),
         Row(
          children: [
            Image.asset('Lapa.png', width: 180, height: 310,), 
            Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration( borderRadius: BorderRadius.circular(10),
                    
                      color:Colors.greenAccent),
                    width: 150,
                    height: 60,
                  
                    child: 
                    
                  MaterialButton(
                    
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Auth_Page()));
                    },
                    child: Text("Начать", style: TextStyle(fontSize: 20),),
                  )
                  ),
                   Image.asset('Lapa.png', width: 180, height: 310,), 
          ],
         ),

           ],
        ),
      ),
    );
  }
}
