using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PawPal.Pages
{
    public class HealthModel : PageModel
    {
        public void OnGet()
        {
        }
        public string ReturnUrl { get; set; }
    }
}
